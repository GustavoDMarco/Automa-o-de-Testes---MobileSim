// ***********************************************************
// Arquivo de suporte principal — carregado antes de cada spec
// ***********************************************************

import './commands'
