# Automação de Testes — E-Commerce QA
**Processo Seletivo QA — VR Software / Mobile Sim 2026**

Automação de testes front-end com **Cypress** cobrindo o fluxo de **Login** do e-commerce [https://onlinesim.com.br/teste-qa/](https://onlinesim.com.br/teste-qa/).

---

## Cenários Cobertos

| ID | Cenário | Tipo |
|----|---------|------|
| CT-001 | Login com CPF e senha corretos | Funcional (Caminho Feliz) |
| CT-002 | Login com senha incorreta | Negativo |
| CT-003 | Login com CPF não cadastrado | Negativo |
| CT-004 | Submissão com campos vazios | Validação |
| CT-005 | Máscara aplicada no campo CPF | Validação |

---

## Seletores Utilizados

Mapeados diretamente via DevTools no ambiente de teste:

| Elemento | Seletor |
|----------|---------|
| Campo CPF | `[data-cy="login-user"] input` |
| Campo Senha | `[data-cy="login-pass"] input` |
| Botão Entrar | `button:contains("Entrar")` |

---

## Estrutura do Projeto

```
cypress-qa/
├── cypress/
│   ├── e2e/
│   │   └── login.cy.js        # Spec de testes de login
│   ├── fixtures/
│   │   └── login.json         # Credenciais de teste
│   └── support/
│       ├── commands.js        # Comandos customizados reutilizáveis
│       └── e2e.js             # Setup global
├── cypress.config.js
├── package.json
└── README.md
```

---

## Instalação e Execução

```bash
# Instalar dependências
npm install

# Abrir interface visual (recomendado)
npm run cy:open

# Rodar em modo headless
npm run cy:run:login
```

---

## Observação sobre Credenciais

As credenciais em `cypress/fixtures/login.json` são dados do ambiente de teste fornecido.  
Em pipelines de CI, substitua por variáveis de ambiente:

```bash
CYPRESS_CPF=xxx CYPRESS_SENHA=yyy npx cypress run
```
