// ***********************************************
// Comandos customizados reutilizáveis
// ***********************************************

/**
 * Acessa a home e abre o modal de login
 */
Cypress.Commands.add('abrirModalLogin', () => {
  cy.visit('/')

  // Aguarda a home carregar
  cy.get('.v-application', { timeout: 10000 }).should('exist')

  // Clica no botão/link que abre o login
  cy.contains('Entrar')
    .first()
    .click()

  // Aguarda o modal aparecer
  cy.get('[data-cy="login-user"]', { timeout: 8000 }).should('be.visible')
})

/**
 * Preenche o campo CPF
 */
Cypress.Commands.add('digitarCPF', (cpf) => {
  cy.get('[data-cy="login-user"] input')
    .clear()
    .type(cpf)
})

/**
 * Preenche o campo Senha
 */
Cypress.Commands.add('digitarSenha', (senha) => {
  cy.get('[data-cy="login-pass"] input')
    .clear()
    .type(senha)
})

/**
 * Clica no botão Entrar
 */
Cypress.Commands.add('clicarEntrar', () => {
  cy.get('button.cy-dialoglogin-entrar')
    .click()
})
