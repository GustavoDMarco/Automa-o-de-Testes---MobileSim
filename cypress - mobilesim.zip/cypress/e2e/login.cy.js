/// <reference types="cypress" />

/**
 * Suite de testes — Fluxo de Login
 * E-Commerce: https://onlinesim.com.br/teste-qa/
 *
 * Seletores reais mapeados via DevTools:
 *   Campo CPF  → [data-cy="login-user"] input
 *   Campo Senha → [data-cy="login-pass"] input
 *   Botão Entrar → button:contains("Entrar")
 *
 * Cenários cobertos:
 *   CT-001 — Login com CPF e senha válidos
 *   CT-002 — Login com senha incorreta
 *   CT-003 — Login com CPF não cadastrado
 *   CT-004 — Campos obrigatórios vazios
 *   CT-005 — Máscara aplicada no campo CPF
 */

describe('Login — E-Commerce QA', () => {
  let cred

  before(() => {
    cy.fixture('login').then((dados) => {
      cred = dados
    })
  })

  beforeEach(() => {
    cy.abrirModalLogin()
  })

  // ─────────────────────────────────────────────────────────
  // CT-001 — Login com CPF e senha corretos
  // ─────────────────────────────────────────────────────────
  it('CT-001 | deve realizar login com CPF e senha corretos', () => {
    cy.digitarCPF(cred.cpf)
    cy.digitarSenha(cred.senha)
    cy.clicarEntrar()

    // Modal de login deve fechar
    cy.get('[data-cy="login-user"]', { timeout: 8000 }).should('not.exist')

    // Algum indicativo de sessão ativa deve aparecer
    cy.get('.v-application').should(($app) => {
      const texto = $app.text().toLowerCase()
      expect(
        texto.includes('sair') ||
        texto.includes('minha conta') ||
        texto.includes('olá') ||
        texto.includes('perfil')
      ).to.be.true
    })
  })

  // ─────────────────────────────────────────────────────────
  // CT-002 — Login com senha incorreta
  // ─────────────────────────────────────────────────────────
  it('CT-002 | deve exibir mensagem de erro com senha incorreta', () => {
    cy.digitarCPF(cred.cpf)
    cy.digitarSenha(cred.senhaInvalida)
    cy.clicarEntrar()

    // Modal deve continuar aberto
    cy.get('[data-cy="login-user"]', { timeout: 8000 }).should('be.visible')

    // Deve exibir mensagem de erro
    cy.get('.v-application').should(($app) => {
      const texto = $app.text().toLowerCase()
      expect(
        texto.includes('inválid')  ||
        texto.includes('incorret') ||
        texto.includes('erro')     ||
        texto.includes('não encontrad')
      ).to.be.true
    })
  })

  // ─────────────────────────────────────────────────────────
  // CT-003 — Login com CPF não cadastrado
  // ─────────────────────────────────────────────────────────
  it('CT-003 | deve exibir mensagem de erro com CPF não cadastrado', () => {
    cy.digitarCPF(cred.cpfInvalido)
    cy.digitarSenha(cred.senha)
    cy.clicarEntrar()

    cy.get('[data-cy="login-user"]', { timeout: 8000 }).should('be.visible')

    cy.get('.v-application').should(($app) => {
      const texto = $app.text().toLowerCase()
      expect(
        texto.includes('inválid')      ||
        texto.includes('não encontrad') ||
        texto.includes('erro')          ||
        texto.includes('incorret')
      ).to.be.true
    })
  })

  // ─────────────────────────────────────────────────────────
  // CT-004 — Campos obrigatórios vazios
  // ─────────────────────────────────────────────────────────
  it('CT-004 | deve impedir login com campos vazios', () => {
    // Não preenche nada, clica direto
    cy.clicarEntrar()

    // Modal deve continuar aberto
    cy.get('[data-cy="login-user"]').should('be.visible')

    // Campos devem indicar erro/obrigatoriedade (Vuetify adiciona v-input--error)
    cy.get('[data-cy="login-user"]').should(($el) => {
      expect(
        $el.hasClass('v-input--error') ||
        $el.text().toLowerCase().includes('obrigatório') ||
        $el.text().toLowerCase().includes('campo')
      ).to.be.true
    })
  })

  // ─────────────────────────────────────────────────────────
  // CT-005 — Máscara no campo CPF (###.###.###-##)
  // ─────────────────────────────────────────────────────────
  it('CT-005 | deve aplicar máscara de CPF ao digitar', () => {
    cy.get('[data-cy="login-user"] input')
      .clear()
      .type('46358628879')  // digita só números
      .invoke('val')
      .then((valor) => {
        // vMaska deve formatar como 463.586.288-79
        expect(valor).to.match(/^\d{3}\.\d{3}\.\d{3}-\d{2}$/)
      })
  })
})
