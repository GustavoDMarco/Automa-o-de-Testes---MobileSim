const { defineConfig } = require('cypress')

module.exports = defineConfig({
  e2e: {
    baseUrl: 'https://onlinesim.com.br/teste-qa',
    viewportWidth: 1280,
    viewportHeight: 720,
    defaultCommandTimeout: 8000,
    screenshotOnRunFailure: true,
    video: false,
    setupNodeEvents(on, config) {},
  },
})
